// Ejecutor de tools para Pioneer Agent — Draft-First Flow
// Llamadas directas a APIs (sin fetch HTTP — regla Vercel serverless)
//
// === CAMBIOS Draft-First ===
// - Nueva tool create_draft: valida → createDraftPost() → retorna draft_id
// - publish_post ahora ACTIVA un draft existente via PUT /v1/posts/{draft_id}
// - Firma simplificada: eliminados parámetros de hallucination tracking
// - Eliminado: auto-inyección de media_urls en retry, bloqueo de regen en retry

import {
  listAccounts,
  getConnectUrl,
  PR_TIMEZONE,
  LateApiError,
  deletePost,
  // Headless OAuth functions
  isHeadlessPlatform,
  getFacebookPages,
  getLinkedInPendingData,
  saveLinkedInOrganization,
  saveFacebookPage,
  getPinterestBoards,
  savePinterestBoard,
  getGoogleBusinessLocations,
  saveGoogleBusinessLocation,
  saveSnapchatProfile,
  // Queue functions
  setupQueueSlots,
  getQueueNextSlot,
} from '@/lib/late-client';
import { generateContent } from '@/lib/content-generator';
import { generateImage } from '@/lib/replicate-client';
import {
  validateAndPrepareDraft,
  validateAndPrepareActivation,
  createDraftWithRetry,
  activateDraftWithRetry,
} from '@/lib/publish-validator';
import type { OAuthPendingData } from '@/lib/oauth-cookie';
import type { Platform } from '@/lib/types';

// === TIPO DE RETORNO DE executeTool ===
export interface ToolResult {
  result: string;
  draftCreated: boolean;      // true si create_draft exitoso — route.ts guarda draft_id
  draftId: string | null;     // ID del draft creado
  publishPostCalled: boolean; // true si publish_post (activateDraft) exitoso
  shouldClearOAuthCookie: boolean;
  linkedInDataToCache: Record<string, unknown> | null;
  connectionOptionsToCache: Array<{ id: string; name: string }> | null;
}

// === DEFAULT RESULT HELPER ===
function defaultResult(result: string, overrides?: Partial<ToolResult>): ToolResult {
  return {
    result,
    draftCreated: false,
    draftId: null,
    publishPostCalled: false,
    shouldClearOAuthCookie: false,
    linkedInDataToCache: null,
    connectionOptionsToCache: null,
    ...overrides,
  };
}

// === DELAY HELPER ===
const CAROUSEL_IMAGE_DELAY_MS = 10_000; // 10s entre imágenes — Replicate free plan

// === EJECUTAR TOOLS ===

export async function executeTool(
  toolName: string,
  toolInput: Record<string, unknown>,
  generateImageWasCalled: boolean,
  lastGeneratedImageUrls: string[],
  // OAuth headless context
  pendingOAuthData: OAuthPendingData | null,
  linkedInCachedData: Record<string, unknown> | null,
  cachedConnectionOptions: Array<{ id: string; name: string }> | null
): Promise<ToolResult> {
  try {
    switch (toolName) {
      case 'list_connected_accounts': {
        const result = await listAccounts();
        return defaultResult(JSON.stringify({
          success: true,
          accounts: result.accounts,
          count: result.accounts.length,
        }));
      }

      case 'generate_connect_url': {
        const input = toolInput as {
          platform: string;
          profile_id: string;
        };
        const result = await getConnectUrl(
          input.platform as Platform,
          input.profile_id
        );

        const headless = isHeadlessPlatform(input.platform);

        return defaultResult(JSON.stringify({
          success: true,
          authUrl: result.authUrl,
          platform: input.platform,
          headless,
          ...(headless && {
            _note_for_pioneer: `Esta plataforma (${input.platform}) usa modo headless. Después de que el cliente autorice, regresará al chat con un mensaje automático. En ese momento debes llamar get_pending_connection para obtener las opciones de selección.`,
          }),
        }));
      }

      case 'generate_content': {
        const input = toolInput as {
          business_name: string;
          business_type: string;
          post_type: string;
          details: string;
          platforms: string[];
          tone?: string;
          include_hashtags?: boolean;
        };
        const result = await generateContent({
          business_name: input.business_name,
          business_type: input.business_type,
          post_type: input.post_type,
          details: input.details,
          platforms: input.platforms,
          tone: input.tone || 'professional',
          include_hashtags: input.include_hashtags !== false,
        });
        return defaultResult(JSON.stringify(result));
      }

      case 'generate_image': {
        const input = toolInput as {
          prompt: string;
          model?: string;
          aspect_ratio?: string;
          count?: number;
        };

        const imageCount = input.count && input.count > 1 ? Math.min(input.count, 10) : 0;

        // === CARRUSEL / MULTI-IMAGEN ===
        if (imageCount > 1) {
          const allImages: string[] = [];
          let totalCostReal = 0;
          let totalCostClient = 0;
          let anyRegenerated = false;
          const errors: string[] = [];

          for (let i = 0; i < imageCount; i++) {
            if (i > 0) {
              console.log(`[Pioneer] Esperando ${CAROUSEL_IMAGE_DELAY_MS / 1000}s antes de generar imagen ${i + 1}/${imageCount}...`);
              await new Promise(resolve => setTimeout(resolve, CAROUSEL_IMAGE_DELAY_MS));
            }

            try {
              const imgResult = await generateImage({
                prompt: input.prompt,
                model: (input.model as 'schnell' | 'pro') || 'schnell',
                aspect_ratio: (input.aspect_ratio as '1:1' | '16:9' | '21:9' | '2:3' | '3:2' | '4:5' | '5:4' | '9:16' | '9:21') || '1:1',
                num_outputs: 1,
              });

              if (imgResult.success && imgResult.images && imgResult.images.length > 0) {
                allImages.push(...imgResult.images);
                totalCostReal += imgResult.cost_real || 0;
                totalCostClient += imgResult.cost_client || 0;
                if (imgResult.regenerated) anyRegenerated = true;
              } else {
                errors.push(`Imagen ${i + 1}: ${imgResult.error || 'Error desconocido'}`);
              }
            } catch (imgError) {
              errors.push(`Imagen ${i + 1}: ${imgError instanceof Error ? imgError.message : 'Error desconocido'}`);
            }
          }

          const allUploadedToLate = allImages.length > 0 && allImages.every(url => url.includes('media.getlate.dev'));
          const someUploadedToLate = allImages.some(url => url.includes('media.getlate.dev'));

          const resultObj: Record<string, unknown> = {
            success: allImages.length > 0,
            images: allImages,
            model: input.model || 'schnell',
            cost_real: totalCostReal,
            cost_client: totalCostClient,
            expires_in: allUploadedToLate
              ? 'Permanente (almacenadas en Late.dev)'
              : someUploadedToLate
                ? 'Mixto: algunas permanentes, algunas expiran en 1 hora'
                : '1 hora para URLs temporales (publicar pronto)',
            uploaded_to_late: allUploadedToLate,
            total_requested: imageCount,
            total_generated: allImages.length,
            ...(errors.length > 0 && { errors }),
          };

          if (allImages.length < imageCount && allImages.length > 0) {
            resultObj._note_for_pioneer = `Solo se generaron ${allImages.length} de ${imageCount} imágenes solicitadas. Costo total: $${totalCostClient.toFixed(3)}. Informa al cliente.`;
          }
          if (anyRegenerated) {
            resultObj._note_for_pioneer = `Algunas imágenes necesitaron regeneración. Costo total: $${totalCostClient.toFixed(3)} (${imageCount} imágenes). Informa al cliente del costo actualizado.`;
          }
          if (errors.length > 0 && allImages.length === 0) {
            resultObj.error = errors[0];
          }

          return defaultResult(JSON.stringify(resultObj));
        }

        // Imagen individual
        const result = await generateImage({
          prompt: input.prompt,
          model: (input.model as 'schnell' | 'pro') || 'schnell',
          aspect_ratio: (input.aspect_ratio as '1:1' | '16:9' | '21:9' | '2:3' | '3:2' | '4:5' | '5:4' | '9:16' | '9:21') || '1:1',
          num_outputs: 1,
        });

        const resultObj: Record<string, unknown> = { ...result };
        if (result.regenerated && result.success) {
          resultObj._note_for_pioneer = `IMPORTANTE: La primera imagen generada no fue accesible y se regeneró automáticamente. El costo total de imagen fue $${result.cost_client.toFixed(3)} (${result.attempts} intentos). Informa al cliente de este costo actualizado.`;
        }

        return defaultResult(JSON.stringify(resultObj));
      }

      // ============================================================
      // === DRAFT-FIRST: create_draft ===
      // ============================================================

      case 'create_draft': {
        const input = toolInput as {
          content: string;
          platforms: Array<{ platform: string; account_id: string }>;
          media_urls?: string[];
        };

        // === VALIDACIÓN PREVENTIVA ===
        const validation = await validateAndPrepareDraft(input, generateImageWasCalled);

        if (!validation.success || !validation.data) {
          return defaultResult(JSON.stringify({
            success: false,
            error: validation.error,
            corrections: validation.corrections,
          }));
        }

        if (validation.corrections && validation.corrections.length > 0) {
          console.log('[Pioneer] Correcciones preventivas en draft:', validation.corrections);
        }

        // === CREAR DRAFT EN LATE.DEV ===
        try {
          const result = await createDraftWithRetry(validation.data);

          if (result.duplicate) {
            return defaultResult(JSON.stringify({
              success: true,
              duplicate: true,
              message: result.message,
              existing_post_id: result.post._id,
              _note_for_pioneer: 'Este contenido ya fue publicado. Informa al cliente que el contenido ya existe y pregunta si desea crear contenido diferente.',
            }));
          }

          const draftId = result.post._id;
          console.log(`[Pioneer] Draft creado exitosamente: ${draftId}`);

          return defaultResult(JSON.stringify({
            success: true,
            draft_id: draftId,
            status: 'draft',
            message: 'Borrador creado en Late.dev. Ahora pregunta al cliente cuándo desea publicar (ahora, programado, o cola). Luego llama publish_post con el draft_id.',
            content_preview: validation.data.content.substring(0, 100) + '...',
            image_included: !!(validation.data.mediaItems && validation.data.mediaItems.length > 0),
            ...(validation.corrections && validation.corrections.length > 0 && {
              _corrections: validation.corrections,
            }),
          }), {
            draftCreated: true,
            draftId,
          });
        } catch (draftError) {
          console.error('[Pioneer] Error creando draft:', draftError);

          const errorMessage =
            draftError instanceof LateApiError
              ? `Error de Late.dev (HTTP ${draftError.status}): ${draftError.body}`
              : draftError instanceof Error
                ? draftError.message
                : 'Error desconocido al crear borrador';

          return defaultResult(JSON.stringify({
            success: false,
            error: errorMessage,
            corrections: validation.corrections,
          }));
        }
      }

      // ============================================================
      // === DRAFT-FIRST: publish_post (activa un draft existente) ===
      // ============================================================

      case 'publish_post': {
        const input = toolInput as {
          draft_id: string;
          publish_now?: boolean;
          scheduled_for?: string;
          timezone?: string;
          use_queue?: boolean;
          queue_profile_id?: string;
        };

        if (!input.draft_id) {
          return defaultResult(JSON.stringify({
            success: false,
            error: 'ERROR: Se requiere draft_id. Debes llamar create_draft PRIMERO para crear el borrador y obtener el draft_id. El flujo correcto es: generate_content → generate_image → create_draft → publish_post.',
          }));
        }

        // === VALIDAR DATOS DE ACTIVACIÓN ===
        const activation = validateAndPrepareActivation(input);

        if (!activation.success || !activation.data) {
          return defaultResult(JSON.stringify({
            success: false,
            error: activation.error,
          }));
        }

        // === ACTIVAR DRAFT VIA PUT /v1/posts/{draft_id} ===
        try {
          const result = await activateDraftWithRetry(input.draft_id, activation.data);

          let successMessage: string;
          if (activation.data.queuedFromProfile) {
            successMessage = 'Post agregado a la cola de publicación. Se publicará automáticamente en el próximo horario disponible.';
          } else if (activation.data.publishNow) {
            successMessage = 'Post publicado exitosamente.';
          } else {
            successMessage = `Post programado para ${activation.data.scheduledFor}.`;
          }

          console.log(`[Pioneer] Draft ${input.draft_id} activado exitosamente: ${successMessage}`);

          return defaultResult(JSON.stringify({
            success: true,
            message: successMessage,
            post: result.post,
            draft_id: input.draft_id,
            ...(activation.data.queuedFromProfile && {
              queued: true,
              queue_profile_id: activation.data.queuedFromProfile,
            }),
            ...(activation.data.scheduledFor && {
              scheduledFor: activation.data.scheduledFor,
              timezone: activation.data.timezone,
            }),
          }), {
            publishPostCalled: true,
          });
        } catch (publishError) {
          console.error('[Pioneer] Error activando draft:', publishError);

          const errorMessage =
            publishError instanceof LateApiError
              ? `Error de Late.dev (HTTP ${publishError.status}): ${publishError.body}`
              : publishError instanceof Error
                ? publishError.message
                : 'Error desconocido al publicar';

          return defaultResult(JSON.stringify({
            success: false,
            error: errorMessage,
            draft_id: input.draft_id,
          }));
        }
      }

      // === TOOL: Queue ===

      case 'setup_queue': {
        const input = toolInput as {
          slots: Array<{ day_of_week: number; time: string }>;
          profile_id?: string;
        };

        const profileId = input.profile_id || '6984c371b984889d86a8b3d6';

        try {
          const formattedSlots = input.slots.map(s => ({
            dayOfWeek: s.day_of_week,
            time: s.time,
          }));

          await setupQueueSlots(profileId, PR_TIMEZONE, formattedSlots, true);

          let nextSlotInfo = '';
          try {
            const nextSlot = await getQueueNextSlot(profileId);
            nextSlotInfo = ` Próximo horario disponible: ${nextSlot.nextSlot}`;
          } catch {
            // No-op: info opcional
          }

          const days = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
          const slotDescriptions = formattedSlots.map(s => `${days[s.dayOfWeek]} a las ${s.time}`);

          return defaultResult(JSON.stringify({
            success: true,
            message: `Cola de publicación configurada: ${slotDescriptions.join(', ')}.${nextSlotInfo}`,
            slots: formattedSlots,
            timezone: PR_TIMEZONE,
            profile_id: profileId,
          }));
        } catch (error) {
          console.error('[Pioneer] Error configurando queue:', error);
          const errorMessage = error instanceof LateApiError
            ? `Error de Late.dev (HTTP ${error.status}): ${error.body}`
            : error instanceof Error ? error.message : 'Error desconocido';

          return defaultResult(JSON.stringify({
            success: false,
            error: `Error configurando cola de publicación: ${errorMessage}`,
          }));
        }
      }

      // ============================================================
      // === TOOLS: OAuth Headless ===
      // ============================================================

      case 'get_pending_connection': {
        const pending = pendingOAuthData;

        if (!pending) {
          return defaultResult(JSON.stringify({
            success: false,
            error: 'No hay conexión pendiente. La sesión de autorización pudo haber expirado (10 minutos). El cliente debe intentar conectar la plataforma de nuevo usando generate_connect_url.',
          }));
        }

        const { platform, step, profileId, tempToken, connectToken, pendingDataToken } = pending;

        console.log(`[Pioneer] get_pending_connection: ${platform} (step: ${step})`);

        try {
          switch (platform) {
            case 'facebook':
            case 'instagram': {
              if (!tempToken || !connectToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan tokens para obtener páginas de Facebook. El cliente debe intentar conectar de nuevo.',
                }));
              }
              const fbResult = await getFacebookPages(profileId, tempToken, connectToken);
              const fbOptions = fbResult.pages.map(p => ({
                id: p.id,
                name: p.name,
                username: p.username || '',
                category: p.category || '',
              }));
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                step,
                options_type: 'pages',
                options: fbOptions,
                message: `Se encontraron ${fbResult.pages.length} página(s) de Facebook. Muestre las opciones al cliente para que elija una.`,
              }), {
                connectionOptionsToCache: fbOptions,
              });
            }

            case 'linkedin': {
              if (!pendingDataToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Falta pendingDataToken para LinkedIn. El cliente debe intentar conectar de nuevo.',
                }));
              }
              const liResult = await getLinkedInPendingData(pendingDataToken);
              const liOptions: Array<{ id: string; name: string }> = [
                { id: 'personal', name: `Cuenta personal de ${liResult.userProfile.displayName}` },
              ];
              if (liResult.organizations) {
                for (const org of liResult.organizations) {
                  liOptions.push({ id: org.id, name: org.name });
                }
              }
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                step,
                options_type: 'accounts',
                options: liOptions,
                message: `Se encontraron ${liOptions.length} opción(es) de LinkedIn. Muestre las opciones al cliente para que elija una.`,
                _linkedin_data: {
                  tempToken: liResult.tempToken,
                  userProfile: liResult.userProfile,
                  organizations: liResult.organizations || [],
                },
              }), {
                linkedInDataToCache: {
                  tempToken: liResult.tempToken,
                  userProfile: liResult.userProfile,
                  organizations: liResult.organizations || [],
                },
                connectionOptionsToCache: liOptions,
              });
            }

            case 'pinterest': {
              if (!tempToken || !connectToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan tokens para obtener boards de Pinterest. El cliente debe intentar conectar de nuevo.',
                }));
              }
              const pinResult = await getPinterestBoards(profileId, tempToken, connectToken);
              const pinOptions = pinResult.boards.map(b => ({
                id: b.id,
                name: b.name,
                description: b.description || '',
              }));
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                step,
                options_type: 'boards',
                options: pinOptions,
                message: `Se encontraron ${pinResult.boards.length} board(s) de Pinterest. Muestre las opciones al cliente.`,
              }), {
                connectionOptionsToCache: pinOptions,
              });
            }

            case 'googlebusiness': {
              if (!tempToken || !connectToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan tokens para obtener ubicaciones de Google Business. El cliente debe intentar conectar de nuevo.',
                }));
              }
              const gbResult = await getGoogleBusinessLocations(profileId, tempToken, connectToken);
              const gbOptions = gbResult.locations.map(l => ({
                id: l.id,
                name: l.name,
                address: l.address || '',
              }));
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                step,
                options_type: 'locations',
                options: gbOptions,
                message: `Se encontraron ${gbResult.locations.length} ubicación(es) de Google Business. Muestre las opciones al cliente.`,
              }), {
                connectionOptionsToCache: gbOptions,
              });
            }

            case 'snapchat': {
              if (!tempToken || !connectToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan tokens para Snapchat. El cliente debe intentar conectar de nuevo.',
                }));
              }
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                step,
                options_type: 'profiles',
                options: [{ id: 'public_profile', name: 'Perfil público de Snapchat' }],
                message: 'Snapchat requiere seleccionar el perfil público para completar la conexión.',
              }), {
                connectionOptionsToCache: [{ id: 'public_profile', name: 'Perfil público de Snapchat' }],
              });
            }

            default:
              return defaultResult(JSON.stringify({
                success: false,
                error: `Plataforma no soportada para conexión headless: ${platform}`,
              }));
          }
        } catch (error) {
          console.error(`[Pioneer] Error obteniendo opciones para ${platform}:`, error);

          if (error instanceof LateApiError && (error.status === 401 || error.status === 403)) {
            return defaultResult(JSON.stringify({
              success: false,
              error: 'Los tokens de autorización expiraron. El cliente debe intentar conectar la plataforma de nuevo.',
              expired: true,
            }), { shouldClearOAuthCookie: true });
          }

          throw error;
        }
      }

      case 'complete_connection': {
        const input = toolInput as {
          platform: string;
          selection_id: string;
          selection_name?: string;
          _linkedin_data?: {
            tempToken: string;
            userProfile: Record<string, unknown>;
            organizations: Array<{ id: string; urn: string; name: string }>;
          };
        };

        const pending = pendingOAuthData;

        if (!pending) {
          return defaultResult(JSON.stringify({
            success: false,
            error: 'No hay conexión pendiente. La sesión pudo haber expirado. El cliente debe intentar conectar de nuevo.',
          }));
        }

        const { platform, profileId, tempToken, connectToken, userProfile } = pending;
        const { selection_id, selection_name } = input;

        console.log(`[Pioneer] complete_connection: ${platform}, selection: ${selection_id} (${selection_name})`);

        try {
          switch (platform) {
            case 'facebook':
            case 'instagram': {
              if (!tempToken || !connectToken || !userProfile) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan datos para guardar la selección de Facebook. El cliente debe intentar conectar de nuevo.',
                }));
              }

              // === BUG 8.5 FIX: Re-fetch pages para validar selection_id ===
              let validatedSelectionId = selection_id;
              try {
                const fbPages = await getFacebookPages(profileId, tempToken, connectToken);
                const realPages = fbPages.pages;

                const exactMatch = realPages.find(p => p.id === selection_id);
                if (!exactMatch) {
                  console.warn(`[Pioneer] ⚠️ selection_id "${selection_id}" no coincide con ninguna page real. Intentando auto-corrección...`);

                  if (selection_name) {
                    const nameMatch = realPages.find(p =>
                      p.name.toLowerCase() === selection_name.toLowerCase()
                    );
                    if (nameMatch) {
                      console.log(`[Pioneer] ⚠️ CORRECCIÓN FB: ID "${selection_id}" → "${nameMatch.id}" (match por nombre: "${nameMatch.name}")`);
                      validatedSelectionId = nameMatch.id;
                    }
                  }

                  if (validatedSelectionId === selection_id && realPages.length === 1) {
                    console.log(`[Pioneer] ⚠️ CORRECCIÓN FB: ID "${selection_id}" → "${realPages[0].id}" (única page disponible: "${realPages[0].name}")`);
                    validatedSelectionId = realPages[0].id;
                  }

                  if (validatedSelectionId === selection_id) {
                    console.warn(`[Pioneer] ⚠️ No se pudo auto-corregir. Intentando con ID original. Pages: ${JSON.stringify(realPages.map(p => ({ id: p.id, name: p.name })))}`);
                  }
                }
              } catch (fetchErr) {
                console.warn('[Pioneer] No se pudieron re-fetch pages para validación:', fetchErr);
              }

              await saveFacebookPage(profileId, validatedSelectionId, tempToken, userProfile, connectToken);
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                message: `Página de Facebook "${selection_name || selection_id}" conectada exitosamente.`,
                connected: true,
              }), { shouldClearOAuthCookie: true });
            }

            case 'linkedin': {
              const liData = input._linkedin_data || (linkedInCachedData as {
                tempToken: string;
                userProfile: Record<string, unknown>;
                organizations: Array<{ id: string; urn: string; name: string }>;
              } | null);

              if (!liData || !connectToken) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan datos de LinkedIn para guardar la selección. El cliente puede necesitar intentar conectar de nuevo.',
                }));
              }

              const isPersonal = selection_id === 'personal';
              const selectedOrg = isPersonal
                ? undefined
                : liData.organizations.find(o => o.id === selection_id);

              await saveLinkedInOrganization(
                profileId,
                liData.tempToken,
                liData.userProfile,
                isPersonal ? 'personal' : 'organization',
                connectToken,
                selectedOrg
              );

              return defaultResult(JSON.stringify({
                success: true,
                platform,
                message: isPersonal
                  ? `LinkedIn conectado como cuenta personal de ${liData.userProfile.displayName || 'usuario'}.`
                  : `LinkedIn conectado como organización "${selectedOrg?.name || selection_id}".`,
                connected: true,
              }), { shouldClearOAuthCookie: true });
            }

            case 'pinterest': {
              if (!tempToken || !connectToken || !userProfile) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan datos para guardar la selección de Pinterest. El cliente debe intentar conectar de nuevo.',
                }));
              }
              await savePinterestBoard(profileId, selection_id, selection_name || selection_id, tempToken, userProfile, connectToken);
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                message: `Board de Pinterest "${selection_name || selection_id}" conectado exitosamente.`,
                connected: true,
              }), { shouldClearOAuthCookie: true });
            }

            case 'googlebusiness': {
              if (!tempToken || !connectToken || !userProfile) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan datos para guardar la ubicación de Google Business. El cliente debe intentar conectar de nuevo.',
                }));
              }
              await saveGoogleBusinessLocation(profileId, selection_id, tempToken, userProfile, connectToken);
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                message: `Ubicación de Google Business "${selection_name || selection_id}" conectada exitosamente.`,
                connected: true,
              }), { shouldClearOAuthCookie: true });
            }

            case 'snapchat': {
              if (!tempToken || !connectToken || !userProfile) {
                return defaultResult(JSON.stringify({
                  success: false,
                  error: 'Faltan datos para guardar el perfil de Snapchat. El cliente debe intentar conectar de nuevo.',
                }));
              }
              await saveSnapchatProfile(profileId, selection_id, tempToken, userProfile, connectToken);
              return defaultResult(JSON.stringify({
                success: true,
                platform,
                message: 'Perfil público de Snapchat conectado exitosamente.',
                connected: true,
              }), { shouldClearOAuthCookie: true });
            }

            default:
              return defaultResult(JSON.stringify({
                success: false,
                error: `Plataforma no soportada para completar conexión: ${platform}`,
              }));
          }
        } catch (error) {
          console.error(`[Pioneer] Error completando conexión para ${platform}:`, error);

          if (error instanceof LateApiError && (error.status === 401 || error.status === 403)) {
            return defaultResult(JSON.stringify({
              success: false,
              error: 'Los tokens de autorización expiraron. El cliente debe intentar conectar la plataforma de nuevo.',
              expired: true,
            }), { shouldClearOAuthCookie: true });
          }

          throw error;
        }
      }

      default:
        return defaultResult(JSON.stringify({
          error: `Tool desconocida: ${toolName}`,
        }));
    }
  } catch (error) {
    console.error(`[Pioneer] Error ejecutando tool ${toolName}:`, error);
    return defaultResult(JSON.stringify({
      success: false,
      error: `Error ejecutando ${toolName}: ${error instanceof Error ? error.message : 'Error desconocido'}`,
    }));
  }
}
